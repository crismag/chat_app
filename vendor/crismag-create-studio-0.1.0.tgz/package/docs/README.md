# Documentation

Create Studio documentation is separated by audience.

## Governing context

- [Project context](project-context.md)
- [Design and engineering standards](design-and-engineering-standards.md)
- [Source and reference policy](source-and-reference-context.md)
- [Implementation plan](implementation-plan.md)

## By audience

- [User documentation](user/README.md)
- [Host integration documentation](integration/README.md)
- [Development documentation](development/README.md)
- [Architecture decisions](decisions/README.md)


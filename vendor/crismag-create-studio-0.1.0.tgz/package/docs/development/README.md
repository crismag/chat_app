# Development documentation

Read the governing documents in the parent directory before implementation.

- [Local setup and commands](setup.md)
- [Repository architecture](architecture.md)
- [Configuration](configuration.md)
- [StudioDocument schema](document-schema.md)
- [Fabric adapter](fabric-adapter.md)
- [Testing and enforcement](testing.md)
- [Phase 5 playground](playground.md)
- [Package and release verification](package-and-release.md)
- [Dependency inventory](dependencies.md)
- [Adapted-source register](adapted-sources.md)

# Adapted-source register

No third-party source has been copied or substantially adapted yet.

For every future adaptation, record:

- feature or behavior;
- project and repository;
- exact source file;
- immutable commit, tag, or release;
- licence;
- affected Create Studio files;
- nature of the adaptation;
- required notice location.

Studying an interaction pattern does not by itself make a project a code donor.


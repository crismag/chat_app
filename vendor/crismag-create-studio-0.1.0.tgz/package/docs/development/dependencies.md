# Dependency inventory

Update this file in the same change that introduces or alters a dependency.

| Package | Repository | Installed version | Licence | Purpose | Production | Notice |
|---|---|---:|---|---|---:|---|
| `fabric` | <https://github.com/fabricjs/fabric.js> | 7.4.0 | MIT, verified at release commit `ce64f450bad811750cb5a75aa749fc1502c644be` | Selected canvas/object engine behind adapter | Yes | `THIRD_PARTY_NOTICES.md`, `third-party-notices.json` |
| `react`, `react-dom` | <https://github.com/facebook/react> | 19.2.8 | MIT | Host-provided UI peer dependencies | Host | Host inventory |
| `typescript` | <https://github.com/microsoft/TypeScript> | 6.0.3 | Apache-2.0 | Strict type checking and declarations | No | Development-only |
| `vite`, `@vitejs/plugin-react` | <https://github.com/vitejs/vite> | 8.2.1, 6.0.5 | MIT | Playground and library build | No | Development-only |
| `eslint`, `typescript-eslint` | <https://github.com/eslint/eslint>, <https://github.com/typescript-eslint/typescript-eslint> | 10.8.1, 8.67.0 | MIT | Static analysis and typed lint rules | No | Development-only |
| `vitest` | <https://github.com/vitest-dev/vitest> | 4.1.10 | MIT | Unit, integration, and component tests | No | Development-only |
| React Testing Library | <https://github.com/testing-library/react-testing-library> | 16.3.2 | MIT | Component behavior and accessibility tests | No | Development-only |
| `@playwright/test` | <https://github.com/microsoft/playwright> | 1.62.1 | Apache-2.0 | Browser smoke tests | No | Development-only |

No dependency is approved merely because it appears in planning. Record the
exact installed version and verified licence when the package is added.

## Adopted Fabric major

Create Studio adopts Fabric.js major 7. Version 7.4.0 is the current stable
release, requires Node.js 20 or newer, and includes the release's documented
security fix. Create Studio itself requires Node.js 22.12 or newer so Vite 8,
ESLint 10, TypeScript 6, Vitest 4, and Playwright share one supported runtime.

The renderer imports Fabric only from `src/canvas/fabric`. A major upgrade must
review upstream release notes and rerun schema, adapter, browser, visual, and
export checks.

Verification sources:

- [Fabric.js 7.4.0 release](https://github.com/fabricjs/fabric.js/releases/tag/v740)
- [Release package metadata](https://github.com/fabricjs/fabric.js/blob/ce64f450bad811750cb5a75aa749fc1502c644be/package.json)
- [Release licence](https://github.com/fabricjs/fabric.js/blob/ce64f450bad811750cb5a75aa749fc1502c644be/LICENSE)
- [Fabric 7 platform guidance](https://fabricjs.com/docs/upgrading/upgrading-to-fabric-70/)

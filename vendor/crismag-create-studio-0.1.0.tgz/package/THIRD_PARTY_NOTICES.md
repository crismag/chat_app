# Third-party notices

Create Studio uses third-party software. The notices below must accompany every
distributed copy or substantial portion of Create Studio that contains the
corresponding software.

## Fabric.js

Package: `fabric`

Version: 7.4.0

Repository: <https://github.com/fabricjs/fabric.js>

Licence: MIT

Release source: https://github.com/fabricjs/fabric.js/commit/ce64f450bad811750cb5a75aa749fc1502c644be

Copyright (c) 2008-2015 Printio (Juriy Zaytsev, Maxim Chernyak)

Copyright (c) 2016-present Andrea Bogazzi, Shachar Nen and Fabric.js contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

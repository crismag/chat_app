# Create Studio

Create Studio is a focused, reusable React visual-composition editor. Its first
consumer is [`crismag/chat_app`](https://github.com/crismag/chat_app), while its
document model, canvas implementation, editing tools, and public API remain
domain-neutral.

Phase 5 extends the useful embeddable editor with an optional host-owned
generated-asset callback, loading/cancellation/retry states, regeneration,
variations, and canonical provenance. Phase 4 added ordered pages and carousel
export, content-rich templates and constrained text slots, logical groups,
callouts, pen/highlighter paths, font-registry validation, explicit overflow
resolution, and touch-sized controls. The existing image, typography, history,
connector, viewport, capability, and deterministic PNG foundations remain.

## Product boundary

Create Studio owns reusable composition capabilities such as documents, pages,
elements, layers, text, images, shapes, drawing, templates, image adjustments,
history, serialization, and deterministic export.

Host applications own identity, persistence, domain interpretation, permanent
assets, provider credentials, generated-image services, publishing, and
sharing.

## Start here

- [Documentation index](docs/README.md)
- [Project context](docs/project-context.md)
- [Design and engineering standards](docs/design-and-engineering-standards.md)
- [Source and reference policy](docs/source-and-reference-context.md)
- [Implementation plan](docs/implementation-plan.md)
- [Architecture decisions](docs/decisions/README.md)

Repository-specific coding-agent instructions are in [`AGENTS.md`](AGENTS.md).

## Development status

Phases 0 through 2 provide the package foundation, deterministic rendering, and
the useful editor interface. Phase 4–5 package work is implemented on stacked
development branches; coordinated C.H.A.T. integration remains separately
versioned in the consuming repository.

The editor deterministically renders final text and composition. Optional AI
image generation is a host-provided source of background or supporting-image
assets; it is not responsible for final typography.

## Development

Node.js 22.12 or newer is required.

```bash
npm ci
npm run dev
```

The Phase 5 playground renders a neutral composition and exercises content-rich
single-page and four-page exports through the public React, host-asset, upload,
persistence, drawing, template, generated-asset, and export contracts. Its
generated imagery is an original local fixture rather than a built-in provider.
Import `@crismag/create-studio/styles.css` with the component stylesheet.

Quality and packaging commands:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
npm run test:e2e
npm run test:visual
npm run check:pack
```

See the [development documentation](docs/development/README.md) and
[integration foundation](docs/integration/README.md) for contracts and limits.

## Third-party software

Fabric.js 7.4.0 is the selected canvas/object engine. It is third-party software
provided under the MIT licence; Create Studio does not claim ownership of it.
Complete required notices are maintained in
[`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md), with structured notice data
for consuming applications in [`third-party-notices.json`](third-party-notices.json).

Create Studio's own public licence has not yet been selected. The repository
must remain private and must not be independently published until that decision
is recorded.
